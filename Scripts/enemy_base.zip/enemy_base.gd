class_name Enemy
extends CharacterBody3D

@export var player: Player
@export var speed: float = 5.0

@onready var catchPlayer_area = $CatchPlayer
@onready var linesight_area = $Pivot/LineOfSightArea
@onready var footsteps_area = $Pivot/FootStepsArea
@onready var waypoint_area = $Pivot/WayPointArea

@onready var raycast_sight = $RayCast3D
@onready var corridor_timer = $CheckCorridorTimer

@export var path_ai: Path3D
@export var timer_waypoint_ai: float = 1.0

var is_chasing = false
var is_following = false
var waypoint_ai = Vector3.ZERO
var waypoint_idx = 0

func _ready() -> void:
	if not player:
		print_debug("NO PLAYER SELECTED ON ITS INSTANCE")
		queue_free()
	$CheckCorridorTimer.wait_time = timer_waypoint_ai

func _physics_process(delta: float) -> void:
	#if catchPlayer_area.is_there_collision:
		#Global.emit_game_over()
	
	if not is_on_floor():
		velocity += get_gravity() * delta
	
	if linesight_area.is_there_collision or footsteps_area.is_there_collision:
		raycast_sight.target_position = to_local(player.global_position)
	else: raycast_sight.target_position = Vector3.ZERO
	
	if raycast_sight.get_collider() is Player:
		is_following = false
		is_chasing = true
		var playerPos = player.global_position
		var direction = (playerPos - global_position).limit_length()
		velocity = direction * speed
		var vector_look_at = Vector3(direction.x, 0, direction.z).normalized()
		linesight_area.get_parent_node_3d().look_at(position + vector_look_at, Vector3.UP, true)
	else:
		is_chasing = false
		#walk towards waypoint
		if not is_following and not is_chasing:
			is_following = true
			waypoint_ai = path_ai.position + path_ai.curve.get_point_position(waypoint_idx)
		var direction = (waypoint_ai - global_position).limit_length()
		if waypoint_area.is_there_collision and waypoint_area.overlapping_body_name == name:
			velocity = Vector3(0, velocity.y, 0)
			if corridor_timer.is_stopped():
				corridor_timer.start()
				waypoint_area.get_child(0).disabled = true
		else:
			velocity = direction * speed
		var vector_look_at = Vector3(direction.x, 0, direction.z).normalized()
		linesight_area.get_parent_node_3d().look_at(position + vector_look_at, Vector3.UP, true)
	waypoint_area.global_position = waypoint_ai
	move_and_slide()

func _on_check_corridor_timer_timeout() -> void:
	if waypoint_idx + 1 >= path_ai.curve.point_count: waypoint_idx = 0
	else: waypoint_idx += 1
	is_following = false
	waypoint_area.get_child(0).disabled = false
